/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { IntroReveal } from './components/IntroReveal';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProblemSection } from './components/ProblemSection';
import { SolutionSection } from './components/SolutionSection';
import { ComparisonSection } from './components/ComparisonSection';
import { AIEngineSection } from './components/AIEngineSection';
import { PortfolioSection } from './components/PortfolioSection';
import { WorkflowSection } from './components/WorkflowSection';
import { ClosingStatement } from './components/ClosingStatement';
import { ContactSection } from './components/ContactSection';
import { NeuralBackground } from './components/NeuralBackground';

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [showNeuralBg, setShowNeuralBg] = useState(false);

  // Scroll to top on mount and disable scroll restoration
  useEffect(() => {
    if ('scrollRestoration' in window.history) {
      window.history.scrollRestoration = 'manual';
    }
    window.scrollTo(0, 0);
  }, []);

  const handleIntroComplete = () => {
    setShowIntro(false);
  };

  useEffect(() => {
    if (!showIntro) {
      // Force scroll to top immediately and after a tiny delay to beat browser scroll restoration
      window.scrollTo(0, 0);
      const timer = setTimeout(() => {
        window.scrollTo(0, 0);
        document.body.style.overflow = '';
      }, 10);
      return () => clearTimeout(timer);
    }
  }, [showIntro]);

  // Listen for scroll to show NeuralBackground after ProblemSection
  useEffect(() => {
    const handleScroll = () => {
      const problemSection = document.getElementById('problem-section');
      if (problemSection) {
        const rect = problemSection.getBoundingClientRect();
        // Show background when problem section is mostly scrolled past
        if (rect.bottom < window.innerHeight / 2) {
          setShowNeuralBg(true);
        } else {
          setShowNeuralBg(false);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <main className="bg-midnight min-h-screen relative">
      <AnimatePresence>
        {showNeuralBg && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-0 pointer-events-none"
          >
            <NeuralBackground />
          </motion.div>
        )}
      </AnimatePresence>

      {showIntro ? (
        <IntroReveal onComplete={handleIntroComplete} />
      ) : (
        <div key="main" className="relative z-10">
          <Navbar />
          <Hero />
          <div id="problem-section">
            <ProblemSection />
          </div>
          <SolutionSection />
          <ComparisonSection />
          <PortfolioSection />
          <ClosingStatement />
          <WorkflowSection />
          <ContactSection />
        </div>
      )}
    </main>
  );
}
