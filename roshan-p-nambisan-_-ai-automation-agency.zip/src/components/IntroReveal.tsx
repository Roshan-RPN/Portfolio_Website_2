import React, { useRef, useEffect } from 'react';
import { motion, useScroll, useTransform, useMotionValueEvent } from 'framer-motion';

interface IntroRevealProps {
  onComplete?: () => void;
}

export const IntroReveal: React.FC<IntroRevealProps> = ({ onComplete }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const hasCompletedRef = useRef(false);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  // 1. Text fades out as we scroll down
  const textOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const textY = useTransform(scrollYProgress, [0, 0.2], [0, -40]);
  
  // 2. Image zooms in dramatically to create a "pass-through" effect
  const imageScale = useTransform(scrollYProgress, [0.1, 0.85], [1, 15]);
  const imageY = useTransform(scrollYProgress, [0, 0.85], [0, 0]); 
  const imageOpacity = useTransform(scrollYProgress, [0.75, 0.95], [1, 0]);
  
  // 3. Curtain panels split to reveal the Hero section underneath
  const leftPanelX = useTransform(scrollYProgress, [0.6, 1], ['0%', '-100%']);
  const rightPanelX = useTransform(scrollYProgress, [0.6, 1], ['0%', '100%']);

  // Trigger completion even earlier to ensure it fires
  useMotionValueEvent(scrollYProgress, "change", (latest) => {
    if (latest >= 0.98 && onComplete && !hasCompletedRef.current) {
      hasCompletedRef.current = true;
      onComplete();
    }
  });

  return (
    <div ref={containerRef} className="relative h-[300vh] w-full bg-midnight">
      {/* Sticky Container */}
      <div className="sticky top-0 h-screen w-full overflow-hidden flex items-center justify-center">
        
        {/* Background Curtain Panels */}
        <div className="absolute inset-0 flex z-10 pointer-events-none">
          <motion.div
            style={{ x: leftPanelX }}
            className="w-1/2 h-full bg-midnight border-r border-electric/10"
          />
          <motion.div
            style={{ x: rightPanelX }}
            className="w-1/2 h-full bg-midnight border-l border-electric/10"
          />
        </div>

        {/* Content Layer */}
        <div className="relative z-30 w-full max-w-5xl px-6 flex flex-col items-center gap-12">
          
          {/* Dashed Border Container */}
          <div className="relative w-full border border-dashed border-electric/30 rounded-3xl p-12 md:p-20 flex flex-col items-center gap-10 bg-midnight/50 backdrop-blur-sm">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-1 bg-electric shadow-[0_0_15px_rgba(0,112,255,0.8)]" />
            
            {/* Image Layer - Now ABOVE the heading */}
            <motion.div
              style={{ 
                scale: imageScale, 
                y: imageY,
                opacity: imageOpacity,
              }}
              className="relative w-full max-w-2xl aspect-[16/10] rounded-2xl overflow-hidden border border-electric/20 shadow-[0_0_50px_rgba(0,112,255,0.3)] bg-midnight"
            >
              <img
                src="https://images.unsplash.com/photo-1675557009875-436f595b189d?auto=format&fit=crop&q=80&w=1200"
                alt="AI Neural Brain"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-midnight/60 to-transparent" />
            </motion.div>

            {/* Heading Layer - Now BELOW the image */}
            <motion.div style={{ opacity: textOpacity, y: textY }} className="flex flex-col items-center">
              <h2 className="text-3xl md:text-5xl lg:text-6xl font-display text-neon text-center leading-[1.2] tracking-tight max-w-4xl">
                What if your business could think <span className="text-electric">faster</span> than your competition?
              </h2>
            </motion.div>
          </div>

          {/* Scroll Indicator */}
          <motion.div 
            style={{ opacity: textOpacity }}
            className="absolute bottom-10 flex flex-col items-center gap-2"
          >
            <motion.div 
              animate={{ y: [0, 5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-px h-8 bg-gradient-to-b from-electric to-transparent" 
            />
          </motion.div>
        </div>
      </div>
    </div>
  );
};
