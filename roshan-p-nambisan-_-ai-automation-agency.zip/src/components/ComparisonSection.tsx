import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XCircle, CheckCircle2, Zap, AlertTriangle, ArrowRight } from 'lucide-react';

const comparisonData = [
  {
    id: 1,
    title: "Time",
    manual: {
      label: "Time Drain",
      desc: "Hours wasted on repetitive manual tasks",
      icon: XCircle
    },
    system: {
      label: "Time Freedom",
      desc: "Operations run automatically with minimal effort",
      icon: CheckCircle2
    }
  },
  {
    id: 2,
    title: "Leads",
    manual: {
      label: "Missed Opportunities",
      desc: "Leads come in but are not captured or followed up",
      icon: XCircle
    },
    system: {
      label: "Every Lead Captured",
      desc: "Automated systems track, respond, and nurture leads",
      icon: CheckCircle2
    }
  },
  {
    id: 3,
    title: "Operations",
    manual: {
      label: "Inconsistent Operations",
      desc: "Processes depend on people, not structure",
      icon: XCircle
    },
    system: {
      label: "Structured Workflows",
      desc: "Everything runs through a clear, connected system",
      icon: CheckCircle2
    }
  },
  {
    id: 4,
    title: "Growth",
    manual: {
      label: "Slow Growth",
      desc: "Scaling becomes difficult and chaotic",
      icon: XCircle
    },
    system: {
      label: "Scalable Growth",
      desc: "Business grows without increasing complexity",
      icon: CheckCircle2
    }
  },
  {
    id: 5,
    title: "Accuracy",
    manual: {
      label: "High Error Rate",
      desc: "Manual work leads to mistakes and inefficiencies",
      icon: XCircle
    },
    system: {
      label: "Reduced Errors",
      desc: "Automation ensures consistency and accuracy",
      icon: CheckCircle2
    }
  },
  {
    id: 6,
    title: "Experience",
    manual: {
      label: "Poor Customer Experience",
      desc: "Delayed responses and inconsistent communication",
      icon: XCircle
    },
    system: {
      label: "Better Customer Experience",
      desc: "Instant responses and smooth interactions",
      icon: CheckCircle2
    }
  }
];

export const ComparisonSection: React.FC = () => {
  const [isActive, setIsActive] = useState(false);

  // Premium Colors
  const premiumGreen = '#00FF9F';
  const warningRed = '#FF3E3E';

  return (
    <section className="relative py-32 bg-[#050505] overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-[0.05] pointer-events-none" 
           style={{ backgroundImage: `radial-gradient(${isActive ? premiumGreen : warningRed} 1px, transparent 1px)`, backgroundSize: '40px 40px' }} />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className={`mb-6 px-6 py-2 rounded-full border text-xs font-mono uppercase tracking-[0.5em] inline-block transition-colors duration-700 ${isActive ? 'border-[#00FF9F]/30 text-[#00FF9F]' : 'border-[#FF3E3E]/30 text-[#FF3E3E]'}`}>
              {isActive ? 'WITH SYSTEM: ACTIVE' : 'WITHOUT SYSTEM: ACTIVE'}
            </div>
            <h2 className="text-6xl md:text-8xl font-display font-black tracking-tighter mb-6 leading-none uppercase">
              The <span className="text-neon">Transformation</span>
            </h2>
            <p className="text-neon/40 font-mono text-sm tracking-[0.4em] uppercase">
              Manufacturing Timeline: {isActive ? 'Optimized Flow' : 'Fragmented Friction'}
            </p>
          </motion.div>
        </div>

        {/* Toggle Control */}
        <div className="flex flex-col items-center gap-8 mb-20">
          <div className="flex items-center gap-8">
            <span className={`text-sm font-mono font-bold tracking-widest transition-colors duration-500 ${!isActive ? 'text-[#FF3E3E]' : 'text-white/20'}`}>WITHOUT SYSTEM</span>
            
            <button 
              onClick={() => setIsActive(!isActive)}
              className={`relative w-24 h-12 rounded-full p-1.5 transition-all duration-500 border ${isActive ? 'bg-[#00FF9F]/20 border-[#00FF9F]/50 shadow-[0_0_20px_rgba(0,255,159,0.3)]' : 'bg-[#FF3E3E]/20 border-[#FF3E3E]/50 shadow-[0_0_20px_rgba(255,62,62,0.3)]'}`}
            >
              <motion.div 
                animate={{ x: isActive ? 48 : 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
                className={`w-9 h-9 rounded-full flex items-center justify-center shadow-lg ${isActive ? 'bg-[#00FF9F]' : 'bg-[#FF3E3E]'}`}
              >
                <Zap className={`w-5 h-5 text-black transition-transform duration-500 ${isActive ? 'rotate-0' : 'rotate-180'}`} />
              </motion.div>
            </button>

            <span className={`text-sm font-mono font-bold tracking-widest transition-colors duration-500 ${isActive ? 'text-[#00FF9F]' : 'text-white/20'}`}>WITH SYSTEM</span>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsActive(!isActive)}
            className={`px-8 py-4 rounded-xl font-display text-sm uppercase tracking-[0.2em] transition-all duration-500 flex items-center gap-3 border-2 ${
              isActive 
                ? 'bg-[#00FF9F]/10 border-[#00FF9F] text-[#00FF9F] shadow-[0_0_40px_rgba(0,255,159,0.2)]' 
                : 'bg-[#FF3E3E]/10 border-[#FF3E3E] text-[#FF3E3E] shadow-[0_0_40px_rgba(255,62,62,0.2)]'
            }`}
          >
            <div className={`w-2 h-2 rounded-full animate-ping ${isActive ? 'bg-[#00FF9F]' : 'bg-[#FF3E3E]'}`} />
            {isActive ? 'Push to Deactivate System' : 'Push to Activate System'}
          </motion.button>
        </div>

        {/* Comparison Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative">
          {/* Connecting Nodes Visual */}
          <div className="absolute inset-0 pointer-events-none z-0 opacity-20">
            <svg className="w-full h-full">
              <pattern id="node-grid" width="100" height="100" patternUnits="userSpaceOnUse">
                <circle cx="50" cy="50" r="1" fill={isActive ? premiumGreen : warningRed} />
              </pattern>
              <rect width="100%" height="100%" fill="url(#node-grid)" />
            </svg>
          </div>

          {comparisonData.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative group"
            >
              <div className={`h-full p-8 rounded-2xl border-2 transition-all duration-700 backdrop-blur-sm relative z-10 ${
                isActive 
                  ? 'bg-[#00FF9F]/[0.03] border-[#00FF9F]/20 shadow-[0_0_30px_rgba(0,255,159,0.05)]' 
                  : 'bg-[#FF3E3E]/[0.03] border-[#FF3E3E]/20 shadow-[0_0_30px_rgba(255,62,62,0.05)]'
              }`}>
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center border transition-all duration-700 ${
                    isActive ? 'bg-[#00FF9F]/20 border-[#00FF9F]/40' : 'bg-[#FF3E3E]/20 border-[#FF3E3E]/40'
                  }`}>
                    <AnimatePresence mode="wait">
                      {!isActive ? (
                        <motion.div
                          key="manual-icon"
                          initial={{ scale: 0, rotate: -90 }}
                          animate={{ scale: 1, rotate: 0 }}
                          exit={{ scale: 0, rotate: 90 }}
                        >
                          <AlertTriangle className="w-6 h-6 text-[#FF3E3E]" />
                        </motion.div>
                      ) : (
                        <motion.div
                          key="system-icon"
                          initial={{ scale: 0, rotate: 90 }}
                          animate={{ scale: 1, rotate: 0 }}
                          exit={{ scale: 0, rotate: -90 }}
                        >
                          <Zap className="w-6 h-6 text-[#00FF9F]" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-[10px] font-mono uppercase tracking-widest transition-colors duration-700 ${isActive ? 'text-[#00FF9F]' : 'text-[#FF3E3E]'}`}>
                        {item.title}
                      </span>
                      {isActive && (
                        <motion.div 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-1.5 h-1.5 rounded-full bg-[#00FF9F] shadow-[0_0_10px_#00FF9F]"
                        />
                      )}
                    </div>

                    <AnimatePresence mode="wait">
                      {!isActive ? (
                        <motion.div
                          key="manual-content"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 10 }}
                        >
                          <h4 className="text-2xl font-display font-bold text-[#FF3E3E] mb-2 leading-tight">
                            {item.manual.label}
                          </h4>
                          <p className="text-white/40 text-sm leading-relaxed">
                            {item.manual.desc}
                          </p>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="system-content"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                        >
                          <h4 className="text-2xl font-display font-bold text-[#00FF9F] mb-2 leading-tight">
                            {item.system.label}
                          </h4>
                          <p className="text-[#00FF9F]/60 text-sm leading-relaxed">
                            {item.system.desc}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Node Connection Line */}
                {isActive && (
                  <motion.div 
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    className="absolute -bottom-[2px] left-8 right-8 h-[2px] bg-[#00FF9F] shadow-[0_0_15px_#00FF9F] origin-left"
                  />
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom Callout */}
        <motion.div 
          animate={{ opacity: 1 }}
          className="mt-20 text-center"
        >
          <div className={`inline-flex items-center gap-6 px-10 py-5 rounded-full border-2 transition-all duration-700 ${
            isActive 
              ? 'bg-[#00FF9F]/10 border-[#00FF9F] text-[#00FF9F] shadow-[0_0_40px_rgba(0,255,159,0.2)]' 
              : 'bg-[#FF3E3E]/10 border-[#FF3E3E] text-[#FF3E3E] shadow-[0_0_40px_rgba(255,62,62,0.2)]'
          }`}>
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-mono uppercase tracking-[0.5em] mb-1 opacity-60">
                Performance Metric
              </span>
              <span className="text-lg font-mono font-black uppercase tracking-[0.2em]">
                {isActive ? 'Efficiency: 99.9% (Optimized)' : 'Efficiency: 14% (Critical Failure)'}
              </span>
            </div>
            <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-[#00FF9F] shadow-[0_0_15px_#00FF9F] animate-pulse' : 'bg-[#FF3E3E] shadow-[0_0_15px_#FF3E3E] animate-ping'}`} />
          </div>
        </motion.div>
      </div>

      {/* Atmospheric Glow */}
      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1400px] h-[1400px] rounded-full blur-[300px] transition-colors duration-1000 pointer-events-none ${isActive ? 'bg-[#00FF9F]/5' : 'bg-[#FF3E3E]/5'}`} />
    </section>
  );
};
