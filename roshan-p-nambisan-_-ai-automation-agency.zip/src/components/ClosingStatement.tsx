import React from 'react';
import { motion } from 'framer-motion';

export const ClosingStatement: React.FC = () => {
  return (
    <section className="relative w-full bg-midnight pt-0 pb-16 md:pb-20 overflow-hidden border-y border-white/5">
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-center"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="mb-4"
            >
              <h2 className="text-5xl md:text-7xl font-display font-black text-white leading-[0.9] tracking-tighter uppercase">
                These are the features: <br />
                <span className="text-electric">Systems that replace work.</span>
              </h2>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(0, 112, 255, 0.4)" }}
                whileTap={{ scale: 0.95 }}
                className="relative z-10 px-10 py-4 bg-electric text-white rounded-xl font-display font-bold text-xs uppercase tracking-[0.2em] transition-all duration-300 shadow-[0_10px_30px_rgba(0,112,255,0.2)]"
              >
                Initialize Your Build
              </motion.button>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-64 h-64 bg-electric/10 blur-[120px] rounded-full" />
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-64 h-64 bg-electric/10 blur-[120px] rounded-full" />
      
      {/* Scroll Indicator / End Line */}
      <motion.div 
        initial={{ height: 0 }}
        whileInView={{ height: 160 }}
        viewport={{ once: true }}
        transition={{ delay: 1, duration: 1.5 }}
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-px bg-gradient-to-t from-electric via-electric/20 to-transparent" 
      />
    </section>
  );
};
