import React from 'react';
import { motion } from 'framer-motion';
import { Bot, Layout, Target, Workflow, Headphones } from 'lucide-react';

const services = [
  {
    icon: Bot,
    title: "AI Automation Systems",
    desc: "Intelligent workflows that eliminate repetitive work.",
    color: "#4FD1C5", // Teal
    items: [
      "Automates daily operations",
      "Reduces human dependency",
      "Minimizes errors",
      "Saves hours every week"
    ]
  },
  {
    icon: Layout,
    title: "High-Converting Websites",
    desc: "Websites designed to turn visitors into leads.",
    color: "#9F7AEA", // Purple
    items: [
      "Conversion-focused design",
      "Fast, responsive, modern UI",
      "Clear user journey flow",
      "Built to capture and qualify leads"
    ]
  },
  {
    icon: Target,
    title: "Lead Capture & Follow-Up Systems",
    desc: "Never miss a potential customer again.",
    color: "#48BB78", // Green
    items: [
      "Automated lead capture",
      "Instant response systems",
      "Follow-up sequences",
      "CRM integration ready"
    ]
  },
  {
    icon: Workflow,
    title: "Workflow Optimization Systems",
    desc: "Structured processes that remove bottlenecks.",
    color: "#ED8936", // Orange
    items: [
      "Connects tools and operations",
      "Reduces delays",
      "Improves team efficiency",
      "Scales smoothly with growth"
    ]
  },
  {
    icon: Headphones,
    title: "AI Reception & Customer Handling",
    desc: "24/7 intelligent interaction system.",
    color: "#F56565", // Red
    items: [
      "Instant replies to inquiries",
      "Handles repetitive customer queries",
      "Improves customer experience",
      "Captures and qualifies leads automatically"
    ]
  }
];

export const SolutionSection: React.FC = () => {
  return (
    <section className="relative min-h-screen w-full bg-midnight py-32 overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-24">
          <motion.h2 
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-5xl md:text-7xl font-display text-neon mb-8"
          >
            What I <span className="text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]">Build</span> For Your Business
          </motion.h2>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-neon/60 max-w-3xl mx-auto text-lg md:text-xl leading-relaxed"
          >
            Five focused systems designed to remove bottlenecks, capture more opportunities, 
            and help your business operate with less friction.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="group relative flex flex-col h-full"
            >
              {/* Card Container */}
              <div 
                className="relative flex flex-col h-full glass-card p-8 border-white/5 transition-all duration-500 backdrop-blur-xl overflow-hidden group-hover:scale-[1.02]"
                style={{ 
                  backgroundColor: `${service.color}08`,
                  borderColor: `${service.color}20`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = `${service.color}60`;
                  e.currentTarget.style.boxShadow = `0 0 40px ${service.color}30`;
                  e.currentTarget.style.backgroundColor = `${service.color}15`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = `${service.color}20`;
                  e.currentTarget.style.boxShadow = 'none';
                  e.currentTarget.style.backgroundColor = `${service.color}08`;
                }}
              >
                {/* Background Shading Glow */}
                <div 
                  className="absolute -top-24 -right-24 w-64 h-64 rounded-full blur-[100px] opacity-20 group-hover:opacity-50 transition-all duration-700"
                  style={{ backgroundColor: service.color }}
                />

                {/* Top Icon with Color Box */}
                <div 
                  className="w-14 h-14 rounded-2xl flex items-center justify-center mb-8 border transition-all duration-500 group-hover:scale-110"
                  style={{ 
                    backgroundColor: `${service.color}20`, 
                    borderColor: `${service.color}50`,
                    color: service.color,
                    boxShadow: `0 0 25px ${service.color}30`
                  }}
                >
                  <service.icon className="w-7 h-7 group-hover:text-white transition-colors" />
                </div>

                {/* Title & Description */}
                <h3 
                  className="text-2xl font-display mb-4 leading-tight transition-all duration-500 group-hover:scale-105 origin-left"
                  style={{ color: 'var(--neon)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = service.color)}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--neon)')}
                >
                  {service.title}
                </h3>
                <p className="text-neon/50 text-sm mb-10 leading-relaxed group-hover:text-neon/90 transition-colors">
                  {service.desc}
                </p>

                {/* Bullet Points in Darker Box */}
                <div className="mt-auto space-y-3">
                  {service.items.map((item, i) => (
                    <div 
                      key={i} 
                      className="p-4 rounded-lg bg-black/60 border border-white/5 text-sm md:text-base text-neon/70 leading-snug group-hover:border-white/20 group-hover:text-neon transition-all duration-300"
                      style={{ borderLeft: `4px solid ${service.color}` }}
                    >
                      {item}
                    </div>
                  ))}
                </div>

                {/* Full Element Brightening Overlay on Hover */}
                <div 
                  className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-30 transition-opacity duration-500"
                  style={{ 
                    background: `radial-gradient(circle at center, ${service.color}44, transparent 70%)` 
                  }}
                />

                {/* Subtle Color Accent at Bottom */}
                <div 
                  className="absolute bottom-0 left-0 w-full h-1 opacity-30 group-hover:opacity-100 transition-all duration-500"
                  style={{ 
                    backgroundColor: service.color,
                    boxShadow: `0 0 30px ${service.color}`
                  }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
