import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, Linkedin, Send, MapPin } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form submission logic would go here
    console.log('Form submitted:', formState);
    alert('Thank you for your message! We will get back to you soon.');
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <section className="relative min-h-screen w-full bg-midnight py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
          {/* Contact Info */}
          <div className="flex flex-col justify-center">
            <motion.h2
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-7xl font-display text-neon mb-8"
            >
              Let's Build the <span className="text-electric">Future</span> Together
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-neon/60 text-lg mb-12 max-w-md"
            >
              Ready to automate your business and scale with AI? 
              Get in touch for a free consultation.
            </motion.p>

            <div className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="flex items-center gap-6 group"
              >
                <div className="w-14 h-14 rounded-xl bg-electric/10 flex items-center justify-center group-hover:bg-electric/20 transition-colors">
                  <Mail className="w-6 h-6 text-electric" />
                </div>
                <div>
                  <p className="text-neon/40 text-sm font-mono uppercase tracking-widest mb-1">Email</p>
                  <a href="mailto:roshanrpn01@gmail.com" className="text-neon text-xl hover:text-electric transition-colors">roshanrpn01@gmail.com</a>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="flex items-center gap-6 group"
              >
                <div className="w-14 h-14 rounded-xl bg-electric/10 flex items-center justify-center group-hover:bg-electric/20 transition-colors">
                  <Phone className="w-6 h-6 text-electric" />
                </div>
                <div>
                  <p className="text-neon/40 text-sm font-mono uppercase tracking-widest mb-1">Phone</p>
                  <a href="tel:+919947648028" className="text-neon text-xl hover:text-electric transition-colors">+91 9947648028</a>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="flex items-center gap-6 group"
              >
                <div className="w-14 h-14 rounded-xl bg-electric/10 flex items-center justify-center group-hover:bg-electric/20 transition-colors">
                  <Linkedin className="w-6 h-6 text-electric" />
                </div>
                <div>
                  <p className="text-neon/40 text-sm font-mono uppercase tracking-widest mb-1">LinkedIn</p>
                  <a href="https://www.linkedin.com/in/roshan-p-nambisan" target="_blank" rel="noopener noreferrer" className="text-neon text-xl hover:text-electric transition-colors">roshan-p-nambisan</a>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="glass-card p-12 relative"
          >
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="space-y-2">
                <label className="text-neon/60 font-mono text-xs uppercase tracking-widest">Full Name</label>
                <input
                  type="text"
                  required
                  value={formState.name}
                  onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-neon focus:outline-none focus:border-electric transition-colors"
                  placeholder="John Doe"
                />
              </div>
              <div className="space-y-2">
                <label className="text-neon/60 font-mono text-xs uppercase tracking-widest">Email Address</label>
                <input
                  type="email"
                  required
                  value={formState.email}
                  onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-neon focus:outline-none focus:border-electric transition-colors"
                  placeholder="john@example.com"
                />
              </div>
              <div className="space-y-2">
                <label className="text-neon/60 font-mono text-xs uppercase tracking-widest">Message</label>
                <textarea
                  required
                  rows={5}
                  value={formState.message}
                  onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-neon focus:outline-none focus:border-electric transition-colors resize-none"
                  placeholder="How can we help you?"
                />
              </div>
              <button
                type="submit"
                className="w-full py-5 bg-electric text-neon font-display font-bold rounded-xl hover:bg-electric/80 transition-all flex items-center justify-center gap-3 group shadow-[0_0_30px_rgba(0,112,255,0.4)]"
              >
                Send Message <Send className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>
            </form>

            {/* Decorative Glow */}
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-electric/20 blur-[60px] rounded-full -z-10" />
          </motion.div>
        </div>

        {/* Footer */}
        <footer className="mt-32 pt-12 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-electric rounded-lg flex items-center justify-center text-neon font-display font-bold">R</div>
            <p className="text-neon/40 text-sm font-mono">© 2026 Roshan P Nambisan. All rights reserved.</p>
          </div>
          <div className="flex gap-8">
            <a href="#" className="text-neon/40 hover:text-electric transition-colors text-sm font-mono uppercase tracking-widest">Privacy Policy</a>
            <a href="#" className="text-neon/40 hover:text-electric transition-colors text-sm font-mono uppercase tracking-widest">Terms of Service</a>
          </div>
        </footer>
      </div>
    </section>
  );
};
