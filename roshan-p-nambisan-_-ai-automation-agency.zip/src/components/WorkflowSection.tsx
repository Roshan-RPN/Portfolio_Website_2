import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useSpring, useTransform, useMotionValue } from 'framer-motion';
import { 
  Binoculars, 
  FlaskConical, 
  Map, 
  Code2, 
  CheckCircle2, 
  TrendingUp 
} from 'lucide-react';

const steps = [
  {
    id: 1,
    title: "Discovery Call",
    desc: "Deep dive into your business ecosystem to map out goals and current friction points.",
    icon: Binoculars,
    color: "#00F0FF"
  },
  {
    id: 2,
    title: "Problem Breakdown",
    desc: "Surgical analysis of bottlenecks and inefficiencies using data-driven insights.",
    icon: FlaskConical,
    color: "#7000FF"
  },
  {
    id: 3,
    title: "Strategy Mapping",
    desc: "Architecting a custom blueprint that aligns technology with your unique business logic.",
    icon: Map,
    color: "#00F0FF"
  },
  {
    id: 4,
    title: "Build & Integrate",
    desc: "Engineering high-performance systems and connecting them into a unified workflow.",
    icon: Code2,
    color: "#7000FF"
  },
  {
    id: 5,
    title: "Test & Optimize",
    desc: "Rigorous stress-testing and refinement to ensure peak operational efficiency.",
    icon: CheckCircle2,
    color: "#00F0FF"
  },
  {
    id: 6,
    title: "Launch & Scale",
    desc: "Deploying your new architecture and scaling operations with precision and speed.",
    icon: TrendingUp,
    color: "#7000FF"
  }
];

interface WorkflowCardProps {
  step: {
    id: number;
    title: string;
    desc: string;
    icon: any;
    color: string;
  };
  index: number;
  activeStep: number;
}

const WorkflowCard: React.FC<WorkflowCardProps> = ({ step, index, activeStep }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useTransform(y, [-100, 100], [10, -10]);
  const rotateY = useTransform(x, [-100, 100], [-10, 10]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    x.set(e.clientX - centerX);
    y.set(e.clientY - centerY);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  const isActive = activeStep > index;
  const isCurrent = activeStep === index + 1;

  return (
    <motion.div
      style={{ rotateX, rotateY, perspective: 1000 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, delay: index * 0.1 }}
      className="relative group cursor-crosshair"
    >
      {/* Holographic Glow */}
      <div className={`absolute -inset-1 rounded-2xl blur-xl transition-opacity duration-500 ${
        isCurrent ? 'opacity-30' : 'opacity-0'
      }`} style={{ backgroundColor: step.color }} />

      <div className={`relative h-full p-8 rounded-2xl border backdrop-blur-sm transition-all duration-500 overflow-hidden ${
        isCurrent ? 'bg-white/[0.05] border-electric shadow-[0_0_40px_rgba(0,240,255,0.15)]' : 
        isActive ? 'bg-white/[0.02] border-white/20' : 'bg-transparent border-white/5 opacity-40'
      }`}>
        {/* Scanline Effect */}
        <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(transparent_0%,rgba(0,240,255,0.05)_50%,transparent_100%)] bg-[length:100%_4px] animate-[scanline_10s_linear_infinite]" />

        {/* Icon & Header */}
        <div className="flex items-start justify-between mb-10">
          <div className={`relative w-20 h-20 flex items-center justify-center transition-all duration-500 ${
            isCurrent ? 'scale-110' : 'scale-100'
          }`}>
            {/* Hexagon Frame */}
            <div className={`absolute inset-0 border-2 rotate-45 transition-all duration-500 ${
              isCurrent ? 'border-electric' : 'border-white/10'
            }`} />
            <step.icon size={36} className={`relative z-10 transition-colors duration-500 ${
              isCurrent ? 'text-electric' : 'text-white/30'
            }`} />
            
            {/* Pulse Ring */}
            {isCurrent && (
              <motion.div 
                initial={{ scale: 0.8, opacity: 0.5 }}
                animate={{ scale: 1.5, opacity: 0 }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="absolute inset-0 border border-electric rounded-full"
              />
            )}
          </div>
          <div className="text-right font-mono">
            <div className="text-[10px] text-white/20 uppercase tracking-widest mb-1">Module_ID</div>
            <div className="text-3xl font-black text-white/10 italic">0{index + 1}</div>
          </div>
        </div>

        {/* Content */}
        <div className="relative z-10">
          <h3 className={`text-3xl font-black mb-4 tracking-tighter uppercase italic transition-colors duration-500 ${
            isCurrent ? 'text-electric' : 'text-white'
          }`}>
            {step.title}
          </h3>
          <p className="text-base text-white/70 leading-relaxed font-medium mb-8">
            {step.desc}
          </p>
        </div>

        {/* Tech Footer */}
        <div className="flex items-center justify-between pt-6 border-t border-white/5">
          <div className="flex gap-1">
            {[1, 2, 3].map(i => (
              <div key={i} className={`w-1 h-1 rounded-full ${isActive || isCurrent ? 'bg-electric' : 'bg-white/10'}`} />
            ))}
          </div>
          <div className="text-[9px] font-mono text-white/20 uppercase tracking-tighter">
            Status: {isCurrent ? 'Active_Sync' : isActive ? 'Complete' : 'Standby'}
          </div>
        </div>

        {/* Corner Accents */}
        <div className="absolute top-0 right-0 w-10 h-10 border-t-2 border-r-2 border-white/5 rounded-tr-2xl" />
        <div className="absolute bottom-0 left-0 w-10 h-10 border-b-2 border-l-2 border-white/5 rounded-bl-2xl" />
      </div>
    </motion.div>
  );
};

export const WorkflowSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const pathProgress = useSpring(scrollYProgress, {
    stiffness: 80,
    damping: 25,
    restDelta: 0.001
  });

  const [activeStep, setActiveStep] = useState(0);
  
  useEffect(() => {
    const unsubscribe = pathProgress.on("change", (v) => {
      const stepIndex = Math.floor(v * steps.length * 1.1);
      setActiveStep(Math.min(stepIndex, steps.length));
    });
    return () => unsubscribe();
  }, [pathProgress]);

  return (
    <section ref={containerRef} className="relative w-full bg-[#030303] py-40 overflow-hidden font-sans">
      {/* Advanced Tech Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 opacity-[0.05]" 
             style={{ backgroundImage: 'linear-gradient(#ffffff 1px, transparent 1px), linear-gradient(90deg, #ffffff 1px, transparent 1px)', backgroundSize: '100px 100px' }} />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,240,255,0.05),transparent_70%)]" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-32 gap-8">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex items-center gap-4 mb-6"
            >
              <div className="h-[2px] w-16 bg-electric" />
              <span className="text-electric text-xs font-mono uppercase tracking-[0.5em]">Operational_Blueprint</span>
            </motion.div>
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-7xl md:text-9xl font-black text-white leading-[0.85] tracking-tighter uppercase italic"
            >
              The <span className="text-electric">Circuit</span> <br />
              of Growth
            </motion.h2>
          </div>
          <div className="hidden lg:block text-right font-mono text-[10px] text-white/20 uppercase tracking-[0.5em] leading-loose">
            System_Initialization: OK <br />
            Data_Stream: Active <br />
            Efficiency: 99.9%
          </div>
        </div>

        {/* Circuit Flowchart */}
        <div className="relative">
          {/* SVG Circuit Path (Advanced) */}
          <svg 
            className="absolute inset-0 w-full h-full pointer-events-none hidden lg:block"
            viewBox="0 0 1200 1200"
            fill="none"
          >
            <motion.path
              d="M 100 200 L 300 200 L 300 600 L 500 600 L 500 200 L 700 200 L 700 600 L 900 600 L 900 200 L 1100 200"
              stroke="rgba(0,240,255,0.05)"
              strokeWidth="1"
            />
            <motion.path
              d="M 100 200 L 300 200 L 300 600 L 500 600 L 500 200 L 700 200 L 700 600 L 900 600 L 900 200 L 1100 200"
              stroke="#00F0FF"
              strokeWidth="3"
              style={{ pathLength: pathProgress }}
              className="drop-shadow-[0_0_12px_rgba(0,240,255,0.8)]"
            />

            {/* Moving Data Packets */}
            {[0, 0.2, 0.4, 0.6, 0.8].map((offset, i) => (
              <motion.g
                key={i}
                style={{ 
                  offsetPath: "path('M 100 200 L 300 200 L 300 600 L 500 600 L 500 200 L 700 200 L 700 600 L 900 600 L 900 200 L 1100 200')"
                }}
                initial={{ offsetDistance: "0%" }}
                animate={{ offsetDistance: "100%" }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity, 
                  ease: "linear",
                  delay: offset * 4
                }}
              >
                <circle r="4" fill="#00F0FF" className="blur-[2px]" />
                <circle r="2" fill="#fff" />
              </motion.g>
            ))}
          </svg>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-32 relative">
            {steps.map((step, index) => (
              <WorkflowCard 
                key={step.id} 
                step={step} 
                index={index} 
                activeStep={activeStep} 
              />
            ))}
          </div>
        </div>
      </div>

      {/* Floating Tech Accents */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[200%] h-[200%] border border-white/[0.01] rounded-full animate-[spin_100s_linear_infinite]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%] border border-white/[0.02] rounded-full animate-[spin_80s_linear_infinite_reverse]" />
      </div>
    </section>
  );
};

const style = document.createElement('style');
style.textContent = `
  @keyframes scanline {
    0% { transform: translateY(-100%); }
    100% { transform: translateY(100%); }
  }
  .cursor-crosshair {
    cursor: crosshair;
  }
`;
document.head.appendChild(style);



