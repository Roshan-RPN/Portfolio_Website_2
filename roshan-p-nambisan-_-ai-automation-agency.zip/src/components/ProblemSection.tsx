import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { 
  AlertCircle, 
  Hand, 
  Unplug, 
  Timer, 
  Droplets, 
  ZapOff, 
  UserX, 
  TrendingDown, 
  Database 
} from 'lucide-react';

const problems = [
  { 
    icon: Hand, 
    title: "Manual Work Dependency", 
    desc: "Your team is stuck in constant manual effort for tasks that should run automatically." 
  },
  { 
    icon: Unplug, 
    title: "No Centralized System", 
    desc: "Tools, data, and workflows are disconnected — nothing works together." 
  },
  { 
    icon: Timer, 
    title: "Inefficient Processes", 
    desc: "Tasks take longer than they should, creating delays and frustration." 
  },
  { 
    icon: Droplets, 
    title: "Lead Leakage", 
    desc: "Potential customers are not tracked, followed up, or converted properly." 
  },
  { 
    icon: ZapOff, 
    title: "Lack of Automation", 
    desc: "Repetitive operations consume time that should be used for growth." 
  },
  { 
    icon: UserX, 
    title: "Poor Customer Handling", 
    desc: "No structured system to respond, engage, and nurture leads consistently." 
  },
  { 
    icon: TrendingDown, 
    title: "Scaling Bottlenecks", 
    desc: "Growth becomes harder because systems can't support increased demand." 
  },
  { 
    icon: Database, 
    title: "Data Without Insight", 
    desc: "You collect data but don't use it effectively to make decisions." 
  }
];

export const ProblemSection: React.FC = () => {
  const [count, setCount] = useState(3);
  const [isBlasted, setIsBlasted] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.3 });

  useEffect(() => {
    if (isInView && count > 0) {
      const timer = setTimeout(() => setCount(count - 1), 1000);
      return () => clearTimeout(timer);
    } else if (isInView && count === 0) {
      const timer = setTimeout(() => setIsBlasted(true), 1200);
      return () => clearTimeout(timer);
    }
  }, [isInView, count]);

  return (
    <section ref={sectionRef} className="relative min-h-screen w-full bg-midnight flex items-center justify-center overflow-hidden py-32">
      <AnimatePresence mode="wait">
        {!isBlasted ? (
          <motion.div
            key="countdown"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ 
              scale: [1, 1.2, 0.8, 5], 
              opacity: 0, 
              filter: ['blur(0px)', 'blur(10px)', 'blur(0px)', 'blur(100px)'],
              rotate: [0, 2, -2, 0]
            }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
            className="text-center z-20"
          >
            <motion.div
              animate={{ opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="text-red-500 font-mono text-sm tracking-[0.5em] uppercase mb-12 flex items-center justify-center gap-4"
            >
              <AlertCircle className="w-5 h-5" />
              CRITICAL SYSTEM ANALYSIS
            </motion.div>
            
            <h2 className="text-neon font-display text-2xl md:text-4xl mb-12 max-w-3xl mx-auto leading-tight">
              Every second your business is <span className="text-red-500">losing opportunity</span>.
            </h2>

            <motion.div 
              key={count}
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-[15rem] md:text-[25rem] font-display font-bold text-red-600 leading-none drop-shadow-[0_0_50px_rgba(220,38,38,0.5)]"
            >
              {count > 0 ? count : "!!!"}
            </motion.div>

            <p className="text-neon/40 font-mono text-xs mt-12 tracking-widest">
              IDENTIFYING LEAKAGE POINTS...
            </p>
          </motion.div>
        ) : (
          <motion.div
            key="problems"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full max-w-7xl px-6"
          >
            <div className="text-center mb-20">
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="inline-block px-4 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-mono tracking-widest uppercase mb-6"
              >
                Diagnostic Report
              </motion.div>
              <h2 className="text-4xl md:text-7xl font-display text-neon mb-6">
                What's Actually <span className="text-red-500">Breaking</span> Your Business:
              </h2>
              <div className="w-24 h-1 bg-red-600 mx-auto rounded-full shadow-[0_0_15px_rgba(220,38,38,0.8)]" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {problems.map((problem, index) => (
                <motion.div
                  key={index}
                  initial={{ y: 30, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  className="group relative"
                >
                  <div className="absolute inset-0 bg-red-600/5 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative glass-card p-8 h-full border-white/10 bg-white/[0.02] hover:border-red-500/30 transition-all duration-500 flex flex-col gap-6">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-600/20">
                        <problem.icon className="w-6 h-6 text-red-500" />
                      </div>
                      <span className="text-red-500/30 font-display text-3xl font-bold">
                        0{index + 1}
                      </span>
                    </div>
                    
                    <div>
                      <h3 className="text-xl font-display text-neon mb-3">
                        {problem.title}
                      </h3>
                      <p className="text-neon/70 text-sm leading-relaxed">
                        {problem.desc}
                      </p>
                    </div>

                    <div className="mt-auto pt-4 flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-[10px] font-mono text-red-500 uppercase tracking-tighter opacity-60">Leakage Point Detected</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background Urgency Accents */}
      {!isBlasted && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(220,38,38,0.05)_0%,transparent_70%)]" />
          <motion.div 
            animate={{ opacity: [0, 0.1, 0] }}
            transition={{ duration: 0.5, repeat: Infinity }}
            className="absolute inset-0 border-[20px] border-red-600/20" 
          />
        </div>
      )}
    </section>
  );
};
