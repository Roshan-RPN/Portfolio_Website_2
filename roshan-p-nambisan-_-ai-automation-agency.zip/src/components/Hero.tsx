import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence, useInView } from 'framer-motion';
import { 
  RefreshCw, 
  Target, 
  TrendingUp, 
  Clock, 
  Mail, 
  Linkedin, 
  Phone,
  Cpu,
  Network,
  Zap,
  ShieldCheck
} from 'lucide-react';

export const Hero: React.FC = () => {
  const [nameText, setNameText] = useState('');
  const [isTypingDone, setIsTypingDone] = useState(false);
  const fullName = "ROSHAN P NAMBISAN";
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0 });
  
  useEffect(() => {
    if (!isInView) return;

    let index = 0;
    const interval = setInterval(() => {
      setNameText(fullName.slice(0, index + 1));
      index++;
      if (index === fullName.length) {
        clearInterval(interval);
        setTimeout(() => setIsTypingDone(true), 500);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [isInView]);

  const features = [
    { icon: <RefreshCw className="w-5 h-5 text-electric" />, text: "Automating Workflows" },
    { icon: <Target className="w-5 h-5 text-electric" />, text: "Capturing Leads" },
    { icon: <TrendingUp className="w-5 h-5 text-electric" />, text: "Scaling Business" },
    { icon: <Clock className="w-5 h-5 text-electric" />, text: "Saving Time and Money" },
  ];

  const floatingNodes = [
    { icon: <Cpu className="w-6 h-6" />, top: "10%", left: "15%", delay: 4 },
    { icon: <Network className="w-6 h-6" />, top: "20%", right: "10%", delay: 4.2 },
    { icon: <Zap className="w-6 h-6" />, bottom: "30%", left: "10%", delay: 4.4 },
    { icon: <ShieldCheck className="w-6 h-6" />, bottom: "20%", right: "15%", delay: 4.6 },
  ];

  return (
    <section ref={sectionRef} className="relative min-h-screen w-full bg-midnight flex flex-col items-center pt-24 pb-20 px-6 overflow-hidden">
      {/* 1. Typewriter Name at the Top */}
      <div className="text-center mb-16 z-20">
        <h1 className="text-4xl md:text-7xl lg:text-8xl font-display text-neon tracking-tight min-h-[1.2em]">
          {nameText}
          {!isTypingDone && isInView && (
            <motion.span 
              animate={{ opacity: [1, 0] }}
              transition={{ duration: 0.8, repeat: Infinity }}
              className="inline-block w-1 h-10 md:h-16 lg:h-20 bg-electric ml-2 align-middle"
            />
          )}
        </h1>
      </div>

      {/* 2. Main Grid Layout */}
      <div className="relative w-full max-w-screen-2xl grid grid-cols-1 lg:grid-cols-3 gap-12 items-center z-10">
        
        {/* Left Column: Features */}
        <AnimatePresence>
          {isTypingDone && (
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="flex flex-col gap-8 order-2 lg:order-1"
            >
              <div>
                <h3 className="text-electric font-display text-lg md:text-xl mb-8 tracking-[0.25em] uppercase border-b border-electric/20 pb-2 inline-block">
                  AI Systems Builder
                </h3>
                <div className="flex flex-col gap-6">
                  {features.map((f, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 1.5 + (i * 0.2) }}
                      className="flex items-center gap-4 group cursor-default"
                    >
                      <div className="p-2.5 rounded-lg bg-electric/10 border border-electric/20 group-hover:border-electric/50 transition-colors">
                        {f.icon}
                      </div>
                      <span className="text-neon/90 font-sans text-lg md:text-xl font-medium group-hover:text-neon transition-colors tracking-wide">
                        {f.text}
                      </span>
                    </motion.div>
                  ))}
                </div>
              </div>

              <motion.button
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                transition={{ delay: 2.5 }}
                className="mt-4 px-10 py-5 bg-electric text-midnight font-display text-base tracking-[0.15em] uppercase rounded-xl shadow-[0_0_25px_rgba(0,112,255,0.4)] hover:shadow-[0_0_40px_rgba(0,112,255,0.6)] transition-all font-bold"
              >
                Get Your Free Audit
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Center Column: Image */}
        <div className="flex justify-center order-1 lg:order-2">
          <AnimatePresence>
            {isTypingDone && (
              <motion.div
                initial={{ y: 500, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ 
                  duration: 1.2, 
                  delay: 0.2,
                  ease: [0.22, 1, 0.36, 1] 
                }}
                className="relative w-full max-w-[400px] aspect-[4/5] rounded-3xl overflow-hidden border border-electric/30 shadow-[0_0_50px_rgba(0,112,255,0.2)]"
              >
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800"
                  alt="Roshan P Nambisan"
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-midnight/60 via-transparent to-transparent" />
                
                {/* Decorative corner elements */}
                <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-electric/50" />
                <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-electric/50" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Contact & About */}
        <AnimatePresence>
          {isTypingDone && (
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="flex flex-col gap-10 order-3"
            >
              {/* Contact Info */}
              <div className="flex flex-col gap-6 bg-midnight/40 p-6 rounded-xl border border-white/5">
                <a 
                  href="mailto:roshanrpn01@gmail.com"
                  className="flex items-center gap-4 text-neon/80 hover:text-electric transition-all group"
                >
                  <div className="p-2 rounded-lg bg-electric/10 border border-electric/20 group-hover:bg-electric/20 transition-colors">
                    <Mail className="w-5 h-5 text-electric" />
                  </div>
                  <span className="text-sm md:text-base font-sans font-semibold tracking-wide">roshanrpn01@gmail.com</span>
                </a>
                <a 
                  href="https://www.linkedin.com/in/roshan-p-nambisan"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 text-neon/80 hover:text-electric transition-all group"
                >
                  <div className="p-2 rounded-lg bg-electric/10 border border-electric/20 group-hover:bg-electric/20 transition-colors">
                    <Linkedin className="w-5 h-5 text-electric" />
                  </div>
                  <span className="text-sm md:text-base font-sans font-semibold tracking-wide">
                    linkedin.com/in/roshan-p-nambisan
                  </span>
                </a>
                <div className="flex items-center gap-4 text-neon/80 group">
                  <div className="p-2 rounded-lg bg-electric/10 border border-electric/20">
                    <Phone className="w-5 h-5 text-electric" />
                  </div>
                  <span className="text-sm md:text-base font-sans font-semibold tracking-wide">9947648028</span>
                </div>
              </div>

              {/* About Me */}
              <div className="bg-electric/5 p-6 rounded-xl border border-electric/10">
                <h4 className="text-electric font-display text-xs tracking-[0.25em] uppercase mb-4 border-b border-electric/20 pb-1 inline-block">
                  About Me
                </h4>
                <p className="text-neon/80 font-sans text-base leading-relaxed font-normal">
                  Mechanical Design Engineer turned AI Systems Builder focused on transforming how businesses operate. I don't just build websites or automation, I design complete systems that eliminate manual work, capture leads, and scale operations. Built and optimized systems through engineering precision, real-world problem solving, and hands-on execution.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 3. Bottom Quote Statement - Redesigned & Wider */}
      <AnimatePresence>
        {isTypingDone && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 3, duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            className="mt-24 w-full max-w-screen-2xl relative group"
          >
            {/* New Look: Banner Style with Accent Lines */}
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-electric/50 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-electric/50 to-transparent" />
            
            <div className="py-12 px-8 md:px-20 bg-midnight/40 backdrop-blur-xl border-x border-electric/10 relative overflow-hidden">
              {/* Animated background pulse */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-electric/5 animate-pulse rounded-full blur-[120px] pointer-events-none" />
              
              <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 md:gap-16">
                <div className="flex-1">
                  <p className="text-neon font-display text-2xl md:text-3xl lg:text-4xl leading-tight tracking-tight">
                    "I build business systems that <span className="text-electric italic">keep working</span> after hours."
                  </p>
                </div>
                <div className="flex-1">
                  <p className="text-neon/80 font-display text-2xl md:text-3xl lg:text-4xl leading-tight tracking-tight border-l-2 border-electric/30 pl-8 md:pl-12">
                    Automating follow-up, capturing leads, and turning daily operations into <span className="text-electric">scalable growth</span>.
                  </p>
                </div>
              </div>
            </div>

            {/* Decorative corner accents */}
            <div className="absolute -top-2 -left-2 w-4 h-4 border-t-2 border-l-2 border-electric" />
            <div className="absolute -bottom-2 -right-2 w-4 h-4 border-b-2 border-r-2 border-electric" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Decorative Nodes (Creative Pop-ups) */}
      <AnimatePresence>
        {isTypingDone && floatingNodes.map((node, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: 1, 
              opacity: 0.4,
              y: [0, -15, 0]
            }}
            transition={{ 
              scale: { delay: node.delay, duration: 0.5 },
              opacity: { delay: node.delay, duration: 0.5 },
              y: { 
                delay: node.delay, 
                duration: 4, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }
            }}
            style={{ 
              position: 'absolute',
              top: node.top,
              left: node.left,
              right: node.right,
              bottom: node.bottom
            }}
            className="p-3 rounded-full bg-electric/10 border border-electric/30 text-electric hidden lg:block"
          >
            {node.icon}
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Background Accents */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-electric/5 blur-[150px] rounded-full pointer-events-none" />
    </section>
  );
};
